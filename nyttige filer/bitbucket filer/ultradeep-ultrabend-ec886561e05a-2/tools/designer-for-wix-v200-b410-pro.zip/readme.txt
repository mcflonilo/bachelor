Designer for Visual Studio WiX Setup Projects, Professional
-------------------------------------------------------------------------------

INSTALLATION PROCEDURE
-------------------------------------------------------------------------------
1. If you are upgrading from the previous version of the product, please,
   uninstall your current version first.
2. Close all Visual Studio instances.
3. Run the included setup.exe file and install the pack contents to your hard
   drive by following the instructions of the installation wizard.


SUPPORT
-------------------------------------------------------------------------------
Feel free to post your questions or issues on our Forums or write to us at
support@add-in-express.com. 

Visit our web-site http://www.add-in-express.com/
for the latest news and updates.

Best regards,
Add-in Express Team,
Add-in Express Ltd.

-------------------------------------------------------------------------------
Copyright (C) Add-in Express Ltd. All rights reserved.
